//
//  player.swift
//  week_five_game
//
//  Created by user154467 on 6/15/19.
//  Copyright © 2019 Alireza. All rights reserved.
//

import Foundation
import UIKit

public class player :  UIImageView  {

}
