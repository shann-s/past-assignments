//
//  GameScene.swift
//  week_five_game
//
//  Created by Alireza Moghaddam on 2019-05-30.
//  Copyright © 2019 Alireza. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene, SKPhysicsContactDelegate {
    
    var myPlayer: SKSpriteNode?
    var myFloor: SKSpriteNode?
    var myCoin: SKSpriteNode?
    var myBird: SKSpriteNode?
    
    var playerCategory: UInt32 = 0x1 << 1   // = 2
    var birdCategory: UInt32 = 0x1 << 2     // = 4
    var coinCategory: UInt32 = 0x1 << 3     // = 8
    var floorCategory: UInt32 = 0x1 << 4   // = 16
    
    
    //Setting contactTestBitMask for a node causes the didBegin function get called once collision happens between two nodes.
    //Also, post effects of collision occur, e.g. bouncing, etc.
    
    //Setting collisionBitMask for a node takes care of ONLY physical collision and its consequences on the scene.
    //It will not call to didBegin function.
   
    //Example: Suppose there are three objects floor, monster and player.
    //We need the player collides with floor and monster. But, monster collides only with the player but not with ground.
    //However, we need sense the collision between the monster and the floor to take some action, say wipe out the monster from the scene.
    
    //In this case,
    //Floor:
        //contactTestBitmask: player and monster
        //collisionBitMask: player
    //Monster:
        //contactTestBitmask: player and floor
        //collisionBitMask: player
    //Player:
        //contactTestBitmask: player and monster
        //collisionBitMask: floor and monster
   
    
    
    //In this example:
    //Monster collides with player and didBegin will be called as a result.
    //Monster does not collide with floor, but didBegin is called.
    //Player collides with the floor and didbegin will be called as a result.
    
    override func sceneDidLoad() {
        
        let bounds = UIScreen.main.bounds
        let width = bounds.size.width
        let height = bounds.size.height
        
        myCoin = childNode(withName: "myCoin") as! SKSpriteNode
        
        myPlayer = childNode(withName: "myPlayer") as! SKSpriteNode
        
        myBird = childNode(withName: "myBird") as! SKSpriteNode
        
        //coin.size = CGSize(width: 100, height: 75)
        
        //coin?.physicsBody? = SKPhysicsBody(rectangleOf: coin.size)
        
        myCoin?.physicsBody?.categoryBitMask = coinCategory
        
        myCoin?.physicsBody?.contactTestBitMask = playerCategory
        
        myPlayer?.physicsBody?.categoryBitMask = playerCategory
        
        myPlayer?.physicsBody?.contactTestBitMask = coinCategory
        
        myBird?.physicsBody?.categoryBitMask = birdCategory
        
        myBird?.physicsBody?.contactTestBitMask = birdCategory
        
        var a = arc4random_uniform(UInt32(width - 15))
        var b = arc4random_uniform(UInt32(height - 15))
        
        myCoin?.position = CGPoint(x: Int(a), y: Int(b))
        
        a = arc4random_uniform(UInt32(width - 20))
        b = arc4random_uniform(UInt32(height - 20))
        
        myPlayer?.position = CGPoint(x: Int(a), y: Int(b))
        
        a = arc4random_uniform(UInt32(width - 30))
        b = arc4random_uniform(UInt32(height - 30))
        
        myBird?.position = CGPoint(x: Int(a), y: Int(b))
        
        let Fx = Int.random(in: -1000 ... 1000)
        let Fy = Int.random(in: -1000 ... 1000)
        
        myCoin?.physicsBody?.applyForce(CGVector(dx: Int(Fx), dy:Int(Fy)))
        
        //addChild(coin)
        
        
    }
    
    override func didMove(to view: SKView) {
        physicsWorld.contactDelegate = self
        
        myFloor = childNode(withName: "floor") as! SKSpriteNode
        myFloor?.physicsBody?.categoryBitMask = floorCategory
        myFloor?.physicsBody?.contactTestBitMask = playerCategory | birdCategory | coinCategory
        myFloor?.physicsBody?.collisionBitMask = playerCategory | birdCategory | coinCategory
        
        myCoin = childNode(withName: "myCoin") as! SKSpriteNode
        myCoin?.physicsBody?.categoryBitMask = coinCategory
        myCoin?.physicsBody?.contactTestBitMask = playerCategory
        myCoin?.physicsBody?.collisionBitMask = floorCategory
        
        myPlayer = childNode(withName: "myPlayer") as! SKSpriteNode
        myPlayer?.physicsBody?.categoryBitMask = playerCategory
        myPlayer?.physicsBody?.contactTestBitMask = birdCategory | coinCategory
        myPlayer?.physicsBody?.collisionBitMask = floorCategory
        
        myBird = childNode(withName: "myBird") as! SKSpriteNode
        myBird?.physicsBody?.categoryBitMask = birdCategory
        myBird?.physicsBody?.contactTestBitMask = playerCategory
        myPlayer?.physicsBody?.collisionBitMask = floorCategory
        /*myPlayer = childNode(withName: "player") as! SKSpriteNode
        myPlayer?.physicsBody?.allowsRotation = false
        myPlayer?.physicsBody?.categoryBitMask = playerCategory
        myPlayer?.physicsBody?.contactTestBitMask = monsterCategory
        myPlayer?.physicsBody?.collisionBitMask = floorCategory | monsterCategory*/
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
    }
    
     func didBegin(_ contact: SKPhysicsContact) {
        print("collision: ")
        print(contact.bodyA.categoryBitMask)
        print(contact.bodyB.categoryBitMask)
        print("-------------------------------")
        
/* var playerCategory: UInt32 = 0x1 << 1   // = 2
 var birdCategory: UInt32 = 0x1 << 2     // = 4
 var coinCategory: UInt32 = 0x1 << 3     // = 8
 var floorCategory: UInt32 = 0x1 << 4   // = 16
 */
        
        if (contact.bodyA.categoryBitMask == 2) {
            if (contact.bodyB.categoryBitMask == 4) {
                // destroy bird
                print("A - player destroyed bird")
                myBird?.removeFromParent()
            }
            if (contact.bodyB.categoryBitMask == 8) {
                //destroy both coin and player
                print("A - player destroyed both")
                myPlayer?.removeFromParent()
                myCoin?.removeFromParent()
            }
        }
        //bird a = 4
        if (contact.bodyA.categoryBitMask == 4) {
            if (contact.bodyB.categoryBitMask == 2) {
                //destroy bird
                print("A - bird destroyed")
                myBird?.removeFromParent()
                
            }
        }
        
        if (contact.bodyA.categoryBitMask == 8) {
            if (contact.bodyB.categoryBitMask == 2) {
                //destroy both coin and player
                print("A - coin destroyed both")
                myPlayer?.removeFromParent()
                myCoin?.removeFromParent()
            }
        }
    }
    
override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    
    
    var Fx = Int.random(in: -1000 ... 1000)
    var Fy = Int.random(in: -1000 ... 1000)
    
    myCoin?.physicsBody?.applyForce(CGVector(dx: Int(Fx), dy:Int(Fy)))
    
    Fx = Int.random(in: -1000 ... 1000)
    Fy = Int.random(in: -1000 ... 1000)
    
    myPlayer?.physicsBody?.applyForce(CGVector(dx: Int(Fx), dy:Int(Fy)))
    
    Fx = Int.random(in: -1000 ... 1000)
    Fy = Int.random(in: -1000 ... 1000)
    
    myBird?.physicsBody?.applyForce(CGVector(dx: Int(Fx), dy:Int(Fy)))
    }
}
