//
//  GameScene.swift
//  midterm_exercise
//
//  Created by user154467 on 7/2/19.
//  Copyright © 2019 user154467. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene, SKPhysicsContactDelegate {
    
    //var coin : SKSpriteNode?
    //var bird : SKSpriteNode?
    //var bullet : SKSpriteNode?
    var scoretable : SKLabelNode?
    var score = 0
    
    //if sprite already exist for collision
    //var myPlayer: SKSpriteNode?
    
    //collision categories
    var gunCategory: UInt32 = 0x1 << 1   // = 2
    var coinCategory: UInt32 = 0x1 << 2  // = 4
    var birdCategory: UInt32 = 0x1 << 3    // = 8
    var bulletCategory: UInt32 = 0x1 << 4  // = 16

    
    override func sceneDidLoad() {
        let gun = SKSpriteNode(imageNamed: "gun.png")
        
        gun.size = CGSize(width: 100, height: 100)
        
        gun.zRotation = 80
        
        gun.position = CGPoint(x: 0, y: -617)
        
        self.addChild(gun)
        
        scoretable = SKLabelNode(fontNamed: "Chalkduster")
        scoretable?.text = String(score)
        scoretable?.fontSize = 25
        scoretable?.position = CGPoint(x: -285.101, y: -606.365)
        
        self.addChild(scoretable!)
        
        //bird generator
        let timer = Timer.scheduledTimer(timeInterval: 2, target: self, selector: #selector(birdSpawn), userInfo: nil, repeats: true)
        
        //coin generator
        let timer2 = Timer.scheduledTimer(timeInterval: 3, target: self, selector: #selector(coinSpawn), userInfo: nil, repeats: true)
    }
    
    @objc func birdSpawn() {
        let bird = SKSpriteNode(imageNamed: "bird.png")
        
        bird.size = CGSize(width: 50, height: 50)
        
        bird.physicsBody = SKPhysicsBody(rectangleOf: bird.size)
        
        //use zero gravity if needed
        //bird?.physicsBody?.isDynamic = false
        
        bird.physicsBody?.categoryBitMask = birdCategory
        bird.physicsBody?.contactTestBitMask = bulletCategory
        bird.physicsBody?.collisionBitMask = coinCategory
        
        let speed = arc4random_uniform(UInt32(20))
        let y = arc4random_uniform(UInt32(640))
        
        bird.position = CGPoint(x: 400, y: Int(y))
        
        self.addChild(bird)
        
        bird.run(SKAction.sequence([SKAction.moveTo(x: -500, duration: TimeInterval(speed)), SKAction.removeFromParent()]))
        
    }
    
    @objc func coinSpawn() {
        let coin = SKSpriteNode(imageNamed: "coin.png")
        
        coin.size = CGSize(width: 75, height: 75)
        
        coin.physicsBody = SKPhysicsBody(rectangleOf: coin.size)
        //coin.physicsBody?.isDynamic = false
        
        coin.physicsBody?.categoryBitMask = coinCategory
        coin.physicsBody?.contactTestBitMask = bulletCategory
        coin.physicsBody?.collisionBitMask = birdCategory
        
        let speed = arc4random_uniform(UInt32(15))
        let y = arc4random_uniform(UInt32(640))
        
        coin.position = CGPoint(x: 500, y: Int(y))
        self.addChild(coin)
        
        coin.run(SKAction.sequence([SKAction.moveTo(x: -500, duration: TimeInterval(speed)), SKAction.removeFromParent()]))
        
    }
    
    override func didMove(to view: SKView) {
        
        physicsWorld.contactDelegate = self
        physicsWorld.gravity = .zero
        print("Did move")
        
        //only do this if sprite already exists
        /*
        myPlayer = childNode(withName: "player") as! SKSpriteNode
        myPlayer?.physicsBody?.allowsRotation = false
        myPlayer?.physicsBody?.categoryBitMask = playerCategory
        myPlayer?.physicsBody?.contactTestBitMask = monsterCategory
        myPlayer?.physicsBody?.collisionBitMask = floorCategory | monsterCategory
        */
    }
    
    
    func touchDown(atPoint pos : CGPoint) {
    }
    
    func touchMoved(toPoint pos : CGPoint) {
    }
    
    func touchUp(atPoint pos : CGPoint) {
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        //spawning sprites
        if let touch = touches.first {
            
            
            let position = touch.location(in: self)
            //print(position)
            
            //position is touch location.
            
            let bullet = SKSpriteNode(imageNamed: "bullet.png")
            
            bullet.size = CGSize(width: 20, height: 25)
            bullet.position = CGPoint(x: 0, y: -610)
            
            bullet.physicsBody = SKPhysicsBody(rectangleOf: bullet.size)
            bullet.physicsBody?.isDynamic = false
            
            bullet.physicsBody?.categoryBitMask = bulletCategory
            bullet.physicsBody?.contactTestBitMask = birdCategory | coinCategory
            
            self.addChild(bullet)
            
            bullet.run(SKAction.sequence([SKAction.move(to: CGPoint(x: position.x - 0, y: position.y), duration: 1), SKAction.removeFromParent()]))
            
            
        }
    }
    
    func didBegin(_ contact: SKPhysicsContact) {
        print("collision: ")
        print(contact.bodyA.categoryBitMask)
        print(contact.bodyB.categoryBitMask)
        print("-------------------------------")
        
        /*
        var gunCategory: UInt32 = 0x1 << 1   // = 2
        var coinCategory: UInt32 = 0x1 << 2  // = 4
        var birdCategory: UInt32 = 0x1 << 3    // = 8
        var bulletCategory: UInt32 = 0x1 << 4  // = 16
        */
        if (contact.bodyA.categoryBitMask == 16) {
            if (contact.bodyB.categoryBitMask == 8) {
                print("--- Bird Killed ---")
                contact.bodyB.node?.removeFromParent()
                score += 1
                scoretable?.text = String(score)
            }
            if (contact.bodyB.categoryBitMask == 4) {
                print("--- Bullet Destroyed ---")
                contact.bodyA.node?.removeFromParent()
                score -= 1
                scoretable?.text = String(score)
            }
        }
        
        if (contact.bodyA.categoryBitMask == 8) {
            if (contact.bodyB.categoryBitMask == 16){
                print("--- Bird Killed ---")
                contact.bodyA.node?.removeFromParent()
                score += 1
                scoretable?.text = String(score)
            }
        }
        
        if (contact.bodyA.categoryBitMask == 4) {
            if (contact.bodyB.categoryBitMask == 16) {
                print("--- Bullet Destroyed ---")
                contact.bodyB.node?.removeFromParent()
                score -= 1
                scoretable?.text = String(score)
            }
        }
        
        
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        
    }
    
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        
    }
    
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }
}
