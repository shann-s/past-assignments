//
//  GameScene.swift
//  final
//
//  Created by user154467 on 7/24/19.
//  Copyright © 2019 user154467. All rights reserved.
//

import SpriteKit
import GameplayKit
import CoreData

class GameScene: SKScene, SKPhysicsContactDelegate {
    //Timers and buttons
    var player: SKSpriteNode?
    var start: SKSpriteNode?
    var exitB: SKSpriteNode?
    var gameStart: Bool?
    var planeTimer: Timer?
    var boatTimer: Timer?
    
    //Contact categories
    var playerCategory: UInt32 = 0x1 << 1    // = 2
    var missileCategory: UInt32 = 0x1 << 2   // = 4
    var boatCategory: UInt32 = 0x1 << 3      // = 8
    var planeCategory: UInt32 = 0x1 << 4     // = 16
    var eBulletCategory: UInt32 = 0x1 << 5   // = 32
    var pMissileCategory: UInt32 = 0x1 << 6 // = 64
    
    //Scoreboard in gameplay
    var scoreboard: SKLabelNode?
    var score: Int = 0
    var lives: SKLabelNode?
    var numLives: Int = 3
    var condition: SKLabelNode?
    var state: Int = 2
    
    //Spawner timers
    var missileSpawner: Timer?
    var planeSpawner: Timer?
    var boatSpawner: Timer?
    
    //Bool to display game over screen and highscores
    var gameOverScreen: Bool?
    
    var hiScoreTitle: SKLabelNode?
    var firstPlayer: SKLabelNode?
    var secondPlayer: SKLabelNode?
    var thirdPlayer: SKLabelNode?
    
    var newScore: Bool?
    var newScoreTitle: SKLabelNode?
    
    var titleScreen: SKLabelNode?
    
    
    //Notice: Known increasing difficulty b̶u̶g̶ feature. Invisible plane/boat continues
    //to shoot at player even to new game
    //Cause: Plane/boat sprite does not reach at expected destination due to collision
    //knocking it away from the screen or not reaching the expected destination
    //Possible fix: make a global timer for enemy shoot timer as well and invalidate
    //when player dies
    //---It is fixed I think?---
    
    //Notice: I decided to make endless waves instead of the original 60 sec timers
    //to make highscore and gameplay interesting. As well as removing the limited ammo
    //count to make way for higher player high scores.
    //I asked for this proposal change and its approved.
    
    //Notice: Displays and sprites sometimes don't show up on start, restart a couple
    //times until all elements are displayed
    //sprites are still in the app and game logic still exist but they are now shown
    //in the view sometimes

    override func sceneDidLoad() {
        //don't let user shoot
        gameStart = false
        
        // first time button and scoreboards initializations
        start = SKSpriteNode(imageNamed: "start")
        start?.position = CGPoint(x: 0, y: -320)
        start?.size = CGSize(width: 250, height: 250)
        start?.name = "start"
        self.addChild(start!)
        
        exitB = SKSpriteNode(imageNamed: "exit")
        exitB?.position = CGPoint(x: 0, y: -550)
        exitB?.size = CGSize(width: 100, height: 100)
        exitB?.name = "exit"
        self.addChild(exitB!)
        
        gameOverScreen = false
        print("start new game")
        numLives = 3
        state = 2
        
        titleScreen = SKLabelNode(fontNamed: "ChalkDuster")
        titleScreen?.text = String("Air Raid Escape")
        titleScreen?.fontSize = 35
        titleScreen?.position = CGPoint(x: 0, y: 425)
        
        hiScoreTitle = SKLabelNode(fontNamed: "ChalkDuster")
        hiScoreTitle?.text = String("Top Players")
        hiScoreTitle?.fontSize = 25
        hiScoreTitle?.position = CGPoint(x: 0, y: 355)
        
        firstPlayer = SKLabelNode(fontNamed: "ChalkDuster")
        firstPlayer?.fontSize = 25
        
        secondPlayer = SKLabelNode(fontNamed: "ChalkDuster")
        secondPlayer?.fontSize = 25
        
        thirdPlayer = SKLabelNode(fontNamed: "ChalkDuster")
        thirdPlayer?.fontSize = 25
        
        self.addChild(hiScoreTitle!)
        self.addChild(titleScreen!)
        var top3 = 0
        
        //fetch top 3 players
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "HighScore")
        request.returnsObjectsAsFaults = false
        let sort = NSSortDescriptor(key: "scores", ascending: false)
        request.sortDescriptors = [sort]
        do {
            let results = try context.fetch(request)
            
            print(results.count)
            
            if results.count > 0 {
                
                for result in results as! [NSManagedObject] {
                    
                    if (top3 == 2) {
                        let playername = result.value(forKey: "playerName") as! String
                        let hiScore = result.value(forKey: "scores") as! Int
                        thirdPlayer?.text = String("\(playername) - \(hiScore)")
                        thirdPlayer?.position = CGPoint(x: 0, y: 250)
                        self.addChild(thirdPlayer!)
                        top3 += 1
                        
                    }
                    if (top3 == 1) {
                        let playername = result.value(forKey: "playerName") as! String
                        let hiScore = result.value(forKey: "scores") as! Int
                        secondPlayer?.text = String("\(playername) - \(hiScore)")
                        secondPlayer?.position = CGPoint(x: 0, y: 275)
                        self.addChild(secondPlayer!)
                        top3 += 1
                        
                    }
                    if (top3 == 0) {
                        let playername = result.value(forKey: "playerName") as! String
                        let hiScore = result.value(forKey: "scores") as! Int
                        firstPlayer?.text = String("\(playername) - \(hiScore)")
                        firstPlayer?.position = CGPoint(x: 0, y: 300)
                        self.addChild(firstPlayer!)
                        top3 += 1
                        
                    }
                    if (top3 == 3) {
                        //top 3 players shown, do nothing
                    }
                    
                }
                
                
            }
            
        }
        catch {
            
        }
        //gameplay scores and lives initialization/setting properties
        scoreboard = SKLabelNode(fontNamed: "ChalkDuster")
        scoreboard?.text = String("Score: \(score)")
        scoreboard?.fontSize = 25
        scoreboard?.position = CGPoint(x: -230, y: -560)
        
        lives = SKLabelNode(fontNamed: "ChalkDuster")
        lives?.text = String("Lives: \(numLives)")
        lives?.fontSize = 25
        lives?.position = CGPoint(x: -230, y: -600)
        
        condition = SKLabelNode(fontNamed: "ChalkDuster")
        condition?.text = String("Condition: Good")
        condition?.fontSize = 25
        condition?.position = CGPoint(x: 100, y: -640)
    }
    
    @objc func planeSpawn() {
        //spawn plane from top screen
        //stay in top position and shoot at player at a steady rate
        
        let Eplane = SKSpriteNode(imageNamed: "Eplane")
        Eplane.zRotation = -90
        Eplane.size = CGSize(width: 100, height: 100)
        Eplane.name = "Eplane"
        
        //x range values for enemy planes to position
        let lValue = -320
        let uValue = 320
        
        let speed = arc4random_uniform(UInt32(3))
        var x = Int(arc4random_uniform(UInt32(uValue - lValue + 1))) +   lValue
        
        Eplane.position = CGPoint(x: x, y: 800)
        Eplane.physicsBody = SKPhysicsBody(rectangleOf: Eplane.size)
        Eplane.physicsBody?.categoryBitMask = planeCategory
        Eplane.physicsBody?.contactTestBitMask = pMissileCategory
        //Eplane.physicsBody?.isDynamic = false
        self.addChild(Eplane)
        
        let ypos = Int(arc4random_uniform(UInt32(450)))
        
        //new x range values
        x = Int(arc4random_uniform(UInt32(uValue - lValue + 1))) +   lValue
        
        Eplane.run(SKAction.move(to: CGPoint(x: x, y: ypos), duration: TimeInterval(speed)))
        
        //plane shoots every 1 sec
        planeTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(planeShoot), userInfo: CGPoint(x: x, y: ypos), repeats: true)
    }
    
    @objc func planeShoot(timer: Timer) {
        let context = timer.userInfo
        let bullet = SKSpriteNode(imageNamed: "bullet-1")
        bullet.position = context as! CGPoint
        bullet.size = CGSize(width: 50, height: 50)
        
        bullet.physicsBody = SKPhysicsBody(rectangleOf: bullet.size)
        bullet.physicsBody?.categoryBitMask = eBulletCategory
        bullet.physicsBody?.contactTestBitMask = playerCategory
        //bullet.physicsBody?.isDynamic = false
        self.addChild(bullet)
        
        //bullet moves to player position and deletes it self
        bullet.run(SKAction.sequence([SKAction.move(to: player!.position, duration: TimeInterval(3)), SKAction.removeFromParent()]))
    }
    
    @objc func boatSpawn() {
        //spawn boat
        //boat spawns from right to left while firing bullets at player
        
        let Eboat = SKSpriteNode(imageNamed: "Eboat")
        Eboat.size = CGSize(width: 100, height: 100)
        Eboat.zRotation = 180
        Eboat.name = "Eboat"
        
        let speed = arc4random_uniform(UInt32(8))
        
        let spawn = arc4random_uniform(UInt32(500))
        
        Eboat.position = CGPoint(x: 500, y: Int(spawn))
        Eboat.physicsBody = SKPhysicsBody(rectangleOf: Eboat.size)
        Eboat.physicsBody?.categoryBitMask = boatCategory
        Eboat.physicsBody?.contactTestBitMask = pMissileCategory
        //Eboat.physicsBody?.isDynamic = false
        self.addChild(Eboat)
        
        
        boatTimer = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(boatShoot), userInfo: CGPoint(x: Eboat.position.x, y: Eboat.position.y), repeats: true)
        
        //added completion:{ self.boatTimer?.invalidate()} so the boat does
        //not shoot when it reaches its destination
        Eboat.run(SKAction.sequence([SKAction.moveTo(x: -500, duration: TimeInterval(speed)), SKAction.removeFromParent()]), completion:{ self.boatTimer?.invalidate()})
        
    }
    
    @objc func boatShoot(timer: Timer) {
        //Boat shoots 3 bullets at the player
        
        let context = timer.userInfo
        let bullet1 = SKSpriteNode(imageNamed: "bullet-1")
        bullet1.position = context as! CGPoint
        bullet1.size = CGSize(width: 50, height: 50)
        
        bullet1.physicsBody = SKPhysicsBody(rectangleOf: bullet1.size)
        bullet1.physicsBody?.categoryBitMask = eBulletCategory
        bullet1.physicsBody?.contactTestBitMask = playerCategory
        //bullet1.physicsBody?.isDynamic = false
        self.addChild(bullet1)
        
        bullet1.run(SKAction.sequence([SKAction.move(to: player!.position, duration: TimeInterval(3)), SKAction.removeFromParent()]))
        
        let bullet2 = SKSpriteNode(imageNamed: "bullet-1")
        bullet2.position = context as! CGPoint
        bullet2.size = CGSize(width: 50, height: 50)
        
        bullet2.physicsBody = SKPhysicsBody(rectangleOf: bullet2.size)
        bullet2.physicsBody?.categoryBitMask = eBulletCategory
        bullet2.physicsBody?.contactTestBitMask = playerCategory
        //bullet2.physicsBody?.isDynamic = false
        self.addChild(bullet2)
        
        bullet2.run(SKAction.sequence([SKAction.moveBy(x: player!.position.x + 25, y: player!.position.y, duration: TimeInterval(3)), SKAction.removeFromParent()]))
        
        let bullet3 = SKSpriteNode(imageNamed: "bullet-1")
        bullet3.position = context as! CGPoint
        bullet3.size = CGSize(width: 50, height: 50)
        
        bullet3.physicsBody = SKPhysicsBody(rectangleOf: bullet3.size)
        bullet3.physicsBody?.categoryBitMask = eBulletCategory
        bullet3.physicsBody?.contactTestBitMask = playerCategory
        //bullet3.physicsBody?.isDynamic = false
        self.addChild(bullet3)
        
        bullet3.run(SKAction.sequence([SKAction.moveBy(x: player!.position.x - 25,y: player!.position.y, duration: TimeInterval(3)), SKAction.removeFromParent()]))
        
    }
    
    @objc func missileSpawn() {
        //dumbfire issile falls from top to bottom
        
        let Emissile = SKSpriteNode(imageNamed: "Emissile")
        Emissile.zRotation = -90
        Emissile.size = CGSize(width: 150, height: 150)
        
        Emissile.physicsBody = SKPhysicsBody(rectangleOf: Emissile.size)
        
        Emissile.physicsBody?.categoryBitMask = missileCategory
        Emissile.physicsBody?.contactTestBitMask = pMissileCategory | playerCategory
        //Emissile.physicsBody?.isDynamic = false
        
        let lValue = -320
        let uValue = 320
        
        let speed = arc4random_uniform(UInt32(10))
        let x = Int(arc4random_uniform(UInt32(uValue - lValue + 1))) +   lValue
        
        Emissile.position = CGPoint(x: x, y: 750)
        
        self.addChild(Emissile)
        
        Emissile.run(SKAction.sequence([SKAction.moveTo(y: -700, duration: TimeInterval(speed)), SKAction.removeFromParent()]))
        
    }
    override func didMove(to view: SKView) {
        physicsWorld.contactDelegate = self
        physicsWorld.gravity = .zero
        print("didmove")
    }
    
    func didBegin(_ contact: SKPhysicsContact) {
        print("collision: ")
        print(contact.bodyA.categoryBitMask)
        print(contact.bodyB.categoryBitMask)
        print("-------------------------------")
        var bodyA = contact.bodyA.categoryBitMask
        var bodyB = contact.bodyB.categoryBitMask
        /*
         var playerCategory: UInt32 = 0x1 << 1    // = 2
         var missileCategory: UInt32 = 0x1 << 2   // = 4
         var boatCategory: UInt32 = 0x1 << 3      // = 8
         var planeCategory: UInt32 = 0x1 << 4     // = 16
         var eBulletCategory: UInt32 = 0x1 << 5   // = 32
         var pMissileCategory: UInt32 = 0x1 << 6 // = 64
        */
        
        //player body
        if (bodyA == 2 || bodyB == 2) {
            if (bodyA == 32 || bodyB == 32) {
                //change player state or remove life
                if ( bodyA == 32 ){
                    contact.bodyA.node?.removeFromParent()
                }
                if (bodyB == 32 ) {
                    contact.bodyB.node?.removeFromParent()
                }
                print("player hit")
                state -= 1
                
            }
            //player contact with missile
            if (bodyA == 4 || bodyB == 4) {
                if ( bodyA == 4 ){
                    contact.bodyA.node?.removeFromParent()
                }
                if (bodyB == 4 ) {
                    contact.bodyB.node?.removeFromParent()
                }
                print("player hit")
                state -= 1
            }
        }
        //player bullets
        if (bodyA == 64 || bodyB == 64) {
            if (bodyA == 4 || bodyB == 4) {
                //missile hit with player bullet, no score change destroy both
                contact.bodyA.node?.removeFromParent()
                contact.bodyA.node?.removeFromParent()
            }
            if (bodyA == 8 || bodyB == 8) {
                //boat hit with player bullet, 2 points
                if (contact.bodyA.node?.name == "Eboat") {
                    contact.bodyA.node?.removeAllChildren()
                    contact.bodyA.node?.removeFromParent()
                    boatTimer?.invalidate()
                    score += 1
                    
                } else {
                    contact.bodyB.node?.removeAllChildren()
                    contact.bodyB.node?.removeFromParent()
                    boatTimer?.invalidate()
                    score += 1
                }
            }
            if (bodyA == 16 || bodyB == 16) {
                //plane hit with player bullet, 1 point
                if (contact.bodyA.node?.name == "Eplane") {
                    contact.bodyA.node?.removeAllChildren()
                    contact.bodyA.node?.removeFromParent()
                    planeTimer?.invalidate()
                    score += 1
                } else {
                    contact.bodyB.node?.removeAllChildren()
                    contact.bodyB.node?.removeFromParent()
                    planeTimer?.invalidate()
                    score += 1
                }
            }
        }
    }
    
    func touchDown(atPoint pos : CGPoint) {
        
    }
    
    func touchMoved(toPoint pos : CGPoint) {
        
    }
    
    func touchUp(atPoint pos : CGPoint) {
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first {
            let position = touch.location(in: self)
            
            let touchedNode = atPoint(position)
            
            if (touchedNode.name == "exit") {
                exit(0)
            }
            if (touchedNode.name == "start") {
                //player clicked on start new game
                
                //remove menu UI
                start?.removeFromParent()
                exitB?.removeFromParent()
                firstPlayer?.removeFromParent()
                secondPlayer?.removeFromParent()
                thirdPlayer?.removeFromParent()
                hiScoreTitle?.removeFromParent()
                newScoreTitle?.removeFromParent()
                titleScreen?.removeFromParent()
                
                //restart game
                gameStart = true
                gameOverScreen = false
                print("---game started---")
                
                //create player sprite
                player = SKSpriteNode(imageNamed: "player")
                player?.position = CGPoint(x: 0, y: -480)
                player?.size = CGSize(width: 100, height: 100)
                player?.name = "player"
                player?.physicsBody = SKPhysicsBody(rectangleOf: player!.size)
                player?.physicsBody?.categoryBitMask = playerCategory
                player?.physicsBody?.contactTestBitMask = eBulletCategory | missileCategory
                //player?.physicsBody?.isDynamic = false
                
                self.addChild(player!)
                
                //bring in gameplay UI
                self.addChild(scoreboard!)
                self.addChild(lives!)
                self.addChild(condition!)
                
                //missile generator
                missileSpawner = Timer.scheduledTimer(timeInterval: 7, target: self, selector: #selector(missileSpawn), userInfo: nil, repeats: true)
                
                //boat generator
                boatSpawner = Timer.scheduledTimer(timeInterval: 8, target: self, selector: #selector(boatSpawn), userInfo: nil, repeats: true)
                
                //plane generator
                planeSpawner = Timer.scheduledTimer(timeInterval: 5, target: self, selector: #selector(planeSpawn), userInfo: nil, repeats: true)
                
            }
            if ( gameStart == true ){
                //game started, player can now move and shoot
                
                if ( position.y < 0 ) {
                    //move player in the bottom half of the screen
                    player?.run(SKAction.move(to: CGPoint(x: position.x, y: position.y), duration: 0.5))
                }
                if ( position.y > 0 ) {
                    //spawn bullets in front of the player
                    let bullet = SKSpriteNode(imageNamed: "bullet")
                    
                    bullet.size = CGSize(width: 30, height: 30)
                    bullet.position = CGPoint(x: player!.position.x, y: player!.position.y + 25)
                    
                    bullet.physicsBody = SKPhysicsBody(rectangleOf: bullet.size)
                    
                    bullet.physicsBody?.categoryBitMask = pMissileCategory
                    bullet.physicsBody?.contactTestBitMask = missileCategory | boatCategory | planeCategory
                    //bullet.physicsBody?.isDynamic = false
                    self.addChild(bullet)
                    
                    bullet.run(SKAction.sequence([SKAction.move(to: CGPoint(x: position.x, y: position.y), duration: 0.5), SKAction.removeFromParent()]))
                }
            }
            
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        
    }
    
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        
    }
    
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
        
        if (gameOverScreen == true) {
            //game over screen
            
            //create the start button
            start = SKSpriteNode(imageNamed: "start")
            start?.position = CGPoint(x: 0, y: -320)
            start?.size = CGSize(width: 250, height: 250)
            start?.name = "start"
            self.addChild(start!)
            //re-add the exit button
            self.addChild(exitB!)
            
            //set this to false so game over screen isn't displayed every frame.
            gameOverScreen = false
            
            //restart lives and state for new game
            print("start new game")
            numLives = 3
            state = 2
            
            //display highscores
            hiScoreTitle = SKLabelNode(fontNamed: "ChalkDuster")
            hiScoreTitle?.text = String("Top Players")
            hiScoreTitle?.fontSize = 25
            hiScoreTitle?.position = CGPoint(x: 0, y: 355)
            
            firstPlayer = SKLabelNode(fontNamed: "ChalkDuster")
            firstPlayer?.fontSize = 25
            
            secondPlayer = SKLabelNode(fontNamed: "ChalkDuster")
            secondPlayer?.fontSize = 25
            
            thirdPlayer = SKLabelNode(fontNamed: "ChalkDuster")
            thirdPlayer?.fontSize = 25
            
            self.addChild(hiScoreTitle!)
            self.addChild(titleScreen!)
            var top3 = 0
            //There is probably a better way than using the var top3 but
            //it's already implemented.
            
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            let context = appDelegate.persistentContainer.viewContext
            
            let request = NSFetchRequest<NSFetchRequestResult>(entityName: "HighScore")
            request.returnsObjectsAsFaults = false
            let sort = NSSortDescriptor(key: "scores", ascending: false)
            request.sortDescriptors = [sort]
            do {
                let results = try context.fetch(request)
                
                print(results.count)
                
                if results.count > 0 {
                    
                    for result in results as! [NSManagedObject] {
                        
                        if (top3 == 2) {
                            let playername = result.value(forKey: "playerName") as! String
                            let hiScore = result.value(forKey: "scores") as! Int
                            thirdPlayer?.text = String("\(playername) - \(hiScore)")
                            thirdPlayer?.position = CGPoint(x: 0, y: 250)
                            self.addChild(thirdPlayer!)
                            top3 += 1
                            print("hiScore: \(hiScore) score: \(score)")
                            if ( hiScore < score ) {
                                //!! if the current score is higher than any of
                                //the top 3 then add it in the leaderboards
                                newScore = true
                            }
                        }
                        if (top3 == 1) {
                            let playername = result.value(forKey: "playerName") as! String
                            let hiScore = result.value(forKey: "scores") as! Int
                            secondPlayer?.text = String("\(playername) - \(hiScore)")
                            secondPlayer?.position = CGPoint(x: 0, y: 275)
                            self.addChild(secondPlayer!)
                            top3 += 1
                            print("hiScore: \(hiScore) score: \(score)")
                            if ( hiScore < score ) {
                                newScore = true
                            }
                        }
                        if (top3 == 0) {
                            let playername = result.value(forKey: "playerName") as! String
                            let hiScore = result.value(forKey: "scores") as! Int
                            firstPlayer?.text = String("\(playername) - \(hiScore)")
                            firstPlayer?.position = CGPoint(x: 0, y: 300)
                            self.addChild(firstPlayer!)
                            top3 += 1
                            print("hiScore: \(hiScore) score: \(score)")
                            if ( hiScore < score ) {
                                newScore = true
                            }
                        }
                        if (top3 == 3) {
                            //top 3 player shown
                        }
                        
                    }
                    
                    
                }
                
            }
            catch {
                
            }
            
            if ( newScore == true ) {
                //player achieved a new highscore
                print("New highscore")
                newScoreTitle = SKLabelNode(fontNamed: "ChalkDuster")
                newScoreTitle?.fontSize = 25
                newScoreTitle?.position = CGPoint(x: 0, y: 225)
                newScoreTitle?.text = String("New player score achieved! - \(score)")
                self.addChild(newScoreTitle!)
                
                let nScore = NSEntityDescription.insertNewObject(forEntityName: "HighScore", into: context)
                
                //set player name as "playerxxx" where x is a random number from 1-100
                let playerNum = Int(arc4random_uniform(UInt32(100)))
                nScore.setValue("New Player\(playerNum)", forKey: "playerName")
                nScore.setValue(score, forKey: "scores")
                
                do{
                    try context.save()
                } catch {
                    print("I/O unsuccessful")
                }
                newScore = false
            }
            //score = 0 was formerly under (if ( numLives == 0 ) { }
            //but high scores would not be saved so it is moved here
            score = 0
        }
        if ( numLives == 0 ) {
            //game over, player has no lives remaining
            //remove player
            player?.removeFromParent()
            
            //stop enemy spawning
            //any enemies on screen aren't destroyed and continue to fire at the player's last position
            missileSpawner?.invalidate()
            boatSpawner?.invalidate()
            planeSpawner?.invalidate()
            
            //new condition to inform player he/she is dead
            condition?.text = String("Condition: Dead")
            
            //set true to display game over screen
            gameOverScreen = true
            
            //removing every label to clean up the screen
            start?.removeFromParent()
            exitB?.removeFromParent()
            scoreboard?.removeFromParent()
            lives?.removeFromParent()
            condition?.removeFromParent()
            print("player dead")
            
            //bullet shoots
            planeTimer?.invalidate()
            boatTimer?.invalidate()
        }
        else {
            //if player is still alive, continue to check their state
            //and display their conditions
            if ( state == 0 ) {
                numLives -= 1
                state = 2
            }
        
            if ( state == 2 ) {
                condition?.text = String("Condition: Good")
            }
        
            if ( state == 1 ) {
                condition?.text = String("Condition: Critical Damage")
            }
        }
        //gameplay lives and scoreboard display.
        lives?.text = String("Lives: \(numLives)")
        scoreboard?.text = String("Score: \(score)")
        
    }
}
