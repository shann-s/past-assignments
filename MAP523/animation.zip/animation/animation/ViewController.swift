//
//  ViewController.swift
//  animation
//
//  Created by Alireza Moghaddam on 2019-05-09.
//  Copyright © 2019 Alireza. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imgBox: UIImageView!
    
    @IBOutlet weak var playerImgBox: UIImageView!
    
    @IBOutlet weak var walk: UIButton!
    @IBOutlet weak var run: UIButton!
    
    @IBOutlet weak var XCoord: UITextField!
    @IBOutlet weak var YCoord: UITextField!
    @IBOutlet weak var stepCount: UILabel!
    var iterator = 1
    var speed = 0
    var steps = 0
    var xCount = 0
    var yCount = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        print("X: ")
        print( playerImgBox.frame.origin.x)
        print("Y: ")
        print(playerImgBox.frame.origin.y)    }
    
    @IBAction func walkPress(_ sender: Any) {
        
        let screenRect = UIScreen.main.bounds
        let screenWidth = screenRect.size.width
        let screenHeight = screenRect.size.height
        let x = CGFloat(NumberFormatter().number(from: XCoord.text!)!)
        
        let y = CGFloat(NumberFormatter().number(from: YCoord.text!)!)
        
        if (x > screenWidth) {
            stepCount.text = "Value out of bounds"
        }
        if (y > screenHeight) {
            stepCount.text = "Value out of bounds"
        }
        else{
        let timer = Timer.scheduledTimer(timeInterval: 0.33, target: self, selector: #selector(updateImageWalk), userInfo: nil, repeats: true)
        }
    }
    
    @IBAction func runPress(_ sender: Any) {
        let timer = Timer.scheduledTimer(timeInterval: 0.10, target: self, selector: #selector(updateImageRun), userInfo: nil, repeats: true)    }
    
    @objc func updateImageWalk() {
        
        let x = CGFloat(NumberFormatter().number(from: XCoord.text!)!)
        
        let y = CGFloat(NumberFormatter().number(from: YCoord.text!)!)
        
        steps += 1
        stepCount.text = String(steps)
    playerImgBox.image = UIImage(named: "frame-\(iterator).png")
        
    iterator += 1
        if (iterator == 5){
            iterator = 1
        }
        
        if (x == playerImgBox.frame.origin.x){
            //stop
        }else {
            
        
            if (Int(XCoord.text!)! > 0) {
            
                playerImgBox.frame.origin.x = playerImgBox.frame.origin.x + 10
            }
            if (Int(XCoord.text!)! < 0 ) {
                playerImgBox.frame.origin.x =   playerImgBox.frame.origin.x - 10
            }
        }
        
        if (y == playerImgBox.frame.origin.y){
            //stop
        }else {
            if (Int(YCoord.text!)! > 0) {
            
                playerImgBox.frame.origin.y = playerImgBox.frame.origin.y + 10
            }
            if (Int(YCoord.text!)! < 0 ) {
                playerImgBox.frame.origin.y = playerImgBox.frame.origin.y - 10
            }
        }
        //Move the image toward right
        //playerImgBox.frame.origin.x = playerImgBox.frame.origin.x + 10
        
        print("X: ")
        print( playerImgBox.frame.origin.x)
        print("Y: ")
        print(playerImgBox.frame.origin.y)
    }
    
    @objc func updateImageRun() {
        
        steps += 1
        stepCount.text = String(steps)
        playerImgBox.image = UIImage(named: "frame-\(iterator).png")
        
        iterator += 1
        if (iterator == 5){
            iterator = 1
        }
        if (Int(XCoord.text!)! > 0) {
            
            playerImgBox.frame.origin.x = playerImgBox.frame.origin.x + 10
        }
        if (Int(XCoord.text!)! < 0 ) {
            playerImgBox.frame.origin.x = playerImgBox.frame.origin.x - 10
        }
        if (Int(YCoord.text!)! > 0) {
            
            playerImgBox.frame.origin.y = playerImgBox.frame.origin.y + 10
        }
        if (Int(YCoord.text!)! < 0 ) {
            playerImgBox.frame.origin.y = playerImgBox.frame.origin.y - 10
        }
        //Move the image toward right
        //playerImgBox.frame.origin.x = playerImgBox.frame.origin.x + 10
        
        print("X: ")
        print( playerImgBox.frame.origin.x)
        print("Y: ")
        print(playerImgBox.frame.origin.y)
    }

}

