//
//  ViewController.swift
//  finalexam
//
//  Created by Shan Ariel Sioson on 2019-08-07.
//  Copyright © 2019 dev. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource, UITableViewDataSource, UITableViewDelegate {
    
    //Answer to Questions
    //1:
    //func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    //unc pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component:
    //Int) -> String?
    
    //3:
    //func f(g:( arg1:Float, arg2:Float) -> Float) -> Int {}
    
    //4:
    //void swapnum2(int &i, int &j) { int temp = i; i = j; j = temp; }
    
    let locationcomponent = 0
    let levelcomponent = 1
    
    var locations = ["Seneca@York", "Seneca@Newnham", "York University"]
    var levels = ["-2" , "-1,", "0", "+1", "+2"]
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if (component == locationcomponent) {
            return locations.count
        } else {
            return levels.count
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component:
        Int) -> String? {
        
        if (component == locationcomponent){
            return locations[row]
        }
        else{
            return levels[row]
        }
        
    }
    
    @IBOutlet weak var picker2: UIPickerView!
    @IBOutlet weak var map: MKMapView!
    @IBOutlet weak var tableData: UITableView!
    
    var lanDelta = 0.01
    var lonDelta = 0.01
    
    var lastcoords : CLLocationCoordinate2D?
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        picker2.selectRow(0, inComponent: 0, animated: true)
        picker2.selectRow(2, inComponent: 1, animated: true)
        
        let latitude: CLLocationDegrees = 43.780938
        let longitude: CLLocationDegrees = -79.497475
        
        
        let span = MKCoordinateSpan(latitudeDelta: lanDelta, longitudeDelta: lonDelta)
        
        let coordinates = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        
        let region = MKCoordinateRegion(center: coordinates, span: span)
        
        map.setRegion(region, animated: true)
        
        let press = UITapGestureRecognizer(target: self, action: #selector(locateT))
        
        map.addGestureRecognizer(press)
    }

    @objc func locateT(gestureRecognizer: UIGestureRecognizer) {
        let touchPoint = gestureRecognizer.location(in: self.map)
        lastcoords = map.convert(touchPoint, toCoordinateFrom: self.map)
        //coordinates
        
        //let annotation  = MKPointAnnotation()
        
        //annotation.title = "New Location"
        
        //annotation.subtitle = "Added New Location!"
        
        //annotation.coordinate = coordinates
        
        //map.addAnnotation(annotation)
        
        
    }
    @IBAction func locatePress(_ sender: Any) {
        //display selected location with zoom level
        let row = picker2.selectedRow(inComponent: 1)
        let selected = levels[row]
        //var levels = ["-2" , "-1,", "0", "+1", "+2"]
        if (selected == "-2") {
            if (lanDelta == 0.01 || lonDelta == 0.01 ){
                
            }else {
            lanDelta -= 0.02
            lonDelta -= 0.02
            }
        } else if (selected == "-1") {
            if (lanDelta == 0.01 || lonDelta == 0.01 ){
                
            }else {
            lanDelta -= 0.01
            lonDelta -= 0.01
            }
        } else if (selected == "+1") {
            lanDelta += 0.01
            lonDelta += 0.01
        } else if (selected == "+2") {
            lanDelta += 0.02
            lonDelta += 0.02
        }
        
        let span = MKCoordinateSpan(latitudeDelta: lanDelta, longitudeDelta: lonDelta)
        
        let region = MKCoordinateRegion(center: lastcoords!, span: span)
        
        map.setRegion(region, animated: true)
        tableData.reloadData()
    }
    @IBAction func pinPress(_ sender: Any) {
        let annotation  = MKPointAnnotation()
        
        annotation.title = "New Location"
        
        annotation.subtitle = "Added New Location!"
        
        annotation.coordinate = lastcoords!
        
        map.addAnnotation(annotation)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    let coordDataTableIdentifier = "coordDataTableIdentifier"
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: coordDataTableIdentifier)
        if ( cell == nil) {
            cell = UITableViewCell(
                style: UITableViewCell.CellStyle.default,
                reuseIdentifier: coordDataTableIdentifier)
            
            cell?.textLabel?.text = "No Data"
        } else {
            cell?.textLabel?.text = "Last Coords Lat: \(lastcoords!.latitude) Lon: \(lastcoords!.longitude)"
            
            //debugging purposes
            print("Last Coords Lat: \(lastcoords!.latitude) Lon: \(lastcoords!.longitude)")
        }
        
        return cell!
    }
}

