//
//  enemy.swift
//  animation
//
//  Created by Alireza Moghaddam on 2019-05-16.
//  Copyright © 2019 Alireza. All rights reserved.
//

import Foundation
import UIKit
import simd

public class enemy :  UIImageView, Pawn  {
    
    //The enemy class extends the UIImageView.
                                        //So, this class is an UIImageView and can be added to ViewController
    private var iterator = 1
    private var motionDirection = 1  //+1 indicates forward and -1 indicates backward
    var health = 100
    var timer: Timer?
    var timer2: Timer?
    let pawn_name = "Alexander"
    var destination: CGPoint?   //This will be used in walk(destination, speed). We define the destination as a global variable for now.
    var enemiesX = [enemy]()
    var totEnemiesX = 0
    
    //init is the constructor of a class
    init(someImg: UIImage, xPos: Int, yPos: Int, w: Int, h: Int)
    {
        super.init(image: someImg)  //Calling the constructor of the parent
        self.frame = CGRect(x: xPos, y: yPos, width: w, height: h )
        
        //-------------------------Beginning of code developed in class during week four--------------------//
        //Add a tap gesture recognizer to myself. Once a tap is detected on me, I will destroy myself by calling destroy_pawn function
        let tap = UITapGestureRecognizer(target: self, action: #selector(destroy_pawn))
        self.addGestureRecognizer(tap)
        self.isUserInteractionEnabled = true
        //-------------------------End of code developed in class during week four--------------------//
    }
    
    //Just to show that we can have multiple constructors in class
    init(someImg: UIImage)
    {
        super.init(image: someImg)
        self.frame = CGRect(x: 100, y: 100, width: 50, height: 70 )
        
        //-------------------------Beginning of code developed in class during week four--------------------//
        //Add a tap gesture recognizer to myself. Once a tap is detected on me, I will destroy myself by calling destroy_pawn function
        let tap = UITapGestureRecognizer(target: self, action: #selector(destroy_pawn))
        self.addGestureRecognizer(tap)
        self.isUserInteractionEnabled = true
        //-------------------------End of code developed in class during week four--------------------//
    }
    
    //This function is used for serialization. This function is used for serialization and we do not explain it here.
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //Sets my position. Note: I am UIImageView
    func setPosition(xPos: CGFloat, yPos: CGFloat){
        
        self.frame.origin = CGPoint(x: xPos, y: yPos)
    }
    
    func getXcoor() -> CGFloat {
        return self.frame.origin.x
    }
    
    
    //-------------------------Beginning of code developed in class during week four--------------------//
    
    //Removes this pawn from the scene
    @objc func destroy_pawn()
    {
        self.removeFromSuperview()
    }
    
    //Walk toward a specific destination with a certain speed
    func walk(des: CGPoint, speed: CGFloat) {
        self.destination = des
        let spd = Double(1/speed)
        timer2 = Timer.scheduledTimer(timeInterval: spd, target: self, selector: #selector(animateToward), userInfo: nil, repeats: true)
    }
    
    //Moving step by step toward a destination
     @objc private func animateToward(){

        //To animate the images
        self.image = UIImage(named: "frame-\(iterator).png")
        iterator += 1
        if (iterator == 5){
            iterator = 1
        }
        
        let bounds = UIScreen.main.bounds
        let width = bounds.size.width
        let height = bounds.size.height
        
        let current_pos = self.frame.origin
        
        //Deleted when past boundaries--
        if (current_pos.x > width)
        {
            destroy_pawn()
        }
        else if(current_pos.x < 0)
        {
            destroy_pawn()
        }
        
        if (current_pos.y > height)
        {
            destroy_pawn()
        }
        else if(current_pos.y < 0)
        {
            destroy_pawn()
        }
        
        //Calculate the vector toward the destination I want to reach
        let moveToward = CGVector(dx: self.destination!.x - current_pos.x, dy: self.destination!.y - current_pos.y)
        
        //Shrink the length of the moveToward vector to length=1. This process is called "Normalization"
        var unit_vector = simd_normalize(simd_double2(x: Double(moveToward.dx), y: Double(moveToward.dy)))
        
        //Update the position along the unit_vector
        self.setPosition(xPos: self.frame.origin.x + CGFloat(unit_vector.x), yPos: self.frame.origin.y + CGFloat(unit_vector.y))
        
        //Check to see if I am close enough to the target, yet.
        let dist_to_target = sqrt(pow((self.frame.origin.x - destination!.x), 2) + pow((self.frame.origin.y - destination!.y), 2))
        
        //print(dist_to_target)
        
        //Consider I have reached the target if I am close enough "2 pixels" in this case. If yes, stop the timer.
        if (dist_to_target < 2){
            print("Target reached!!!")
            timer2?.invalidate()
        }
    }
    //-------------------------End of code developed in class during week four--------------------//
   
    
    func walkInPlace()
    {
        let spd = Double(1.0)
        
        timer = Timer.scheduledTimer(timeInterval: 0.33, target: self, selector: #selector(animateInPlace), userInfo: nil, repeats: true)
    }
    
    @objc private func animateInPlace(){
        
        //Kill myself whenever I get transparent and invisible
        if (self.alpha < 0) {
            
            self.timer!.invalidate()
            self.removeFromSuperview()
            //print("Wiped out from view!!!")
        }
        
        self.image = UIImage(named: "frame-\(iterator).png")
        iterator += 1
        
        if (iterator == 5){
            iterator = 1
        }
        
    }
    
    //The classic walk method we developed before
    func walk(speed: CGFloat)
    {
        let spd = Double(1/speed)
        
        timer = Timer.scheduledTimer(timeInterval: spd, target: self, selector: #selector(animate), userInfo: nil, repeats: true)
    }
        
    @objc private func animate(){
        
        //Kill myself whenever I get transparent and invisible
        if (self.alpha < 0) {
            
            self.timer!.invalidate()
            self.removeFromSuperview()
            //print("Wiped out from view!!!")
        }
        
        self.image = UIImage(named: "frame-\(iterator).png")
        iterator += 1
        
        if (iterator == 5){
            iterator = 1
        }
        let stepSize = 10
         self.setPosition(xPos: self.frame.origin.x + CGFloat(motionDirection * stepSize), yPos: self.frame.origin.y)
        
        let bounds = UIScreen.main.bounds
        let width = bounds.size.width
        
        //When colliding with walls, the health gets decremented by 20
        //and transparency is reduced by 20%
        if (self.frame.origin.x > width - self.frame.width)
        {
            motionDirection = -1
            self.health -= 20
            self.alpha -= 0.2
        }
        else if(self.frame.origin.x < 0)
        {
            motionDirection = 1
            self.health -= 20
            self.alpha -= 0.2
        }
        
    }
    
    public class bullet : enemy {
        
        struct bulletdirection {
            
            var x: Int
            var y: Int
        }
        
        struct spawnpoint {
            var xPos: Int
            var yPos: Int
        }
        var speed: CGFloat = 0.0
        var spawn : spawnpoint = spawnpoint(xPos: 0, yPos: 0)
        var dir : bulletdirection = bulletdirection(x: 0, y: 0)
        var xDir = 1
        var yDir = 1
        
        
        init(sImg: UIImage, xxPos: Int, yyPos: Int, ww: Int, hh: Int, xDir: Int, yDir: Int) {
            
            //super.init()
            super.init(someImg: sImg, xPos: xxPos, yPos: yyPos, w: ww, h: hh)
            self.frame = CGRect(x: xxPos, y: yyPos, width: ww, height: hh )
            let spawn = spawnpoint(xPos: xxPos, yPos: yyPos)
            let dir = bulletdirection(x: 1, y: yDir)
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
        
        func firing(enemies: [enemy], totEnemies: Int)
        {
            enemiesX = enemies
            totEnemiesX = totEnemies
            timer = Timer.scheduledTimer(timeInterval: 0.33, target: self, selector: #selector(shot), userInfo: nil, repeats: true)
            
        }
        
        @objc private func shot(){
            
            for i in 0...totEnemiesX {
                if (self.frame.origin.x == enemiesX[i].getXcoor()) {
                    enemiesX[i].removeFromSuperview()
                }
            }
            
            self.image = UIImage(named: "bullet-bill.png")
            
            let stepSize = 10
            self.setPosition(xPos: self.frame.origin.x + CGFloat(1 * stepSize), yPos: self.frame.origin.y)
            
            let bounds = UIScreen.main.bounds
            let width = bounds.size.width
            
            //When colliding with walls, the health gets decremented by 20
            //and transparency is reduced by 20%
            if (self.frame.origin.x > width - self.frame.width)
            {
                self.timer!.invalidate()
                self.removeFromSuperview()
            }
            else if(self.frame.origin.x < 0)
            {
                //motionDirection = 1
                //self.health -= 20
                //self.alpha -= 0.2
            }
            
        }
    }
    
}

