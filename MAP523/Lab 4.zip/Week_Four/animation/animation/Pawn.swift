//
//  pawn.swift
//  animation
//
//  Created by Alireza Moghaddam on 2019-05-21.
//  Copyright © 2019 Alireza. All rights reserved.
//

import Foundation
import UIKit

//A Protocol (Interface) for a pawn that may be involved in our game. All classes that implement this protocol, must follow this interface
protocol Pawn{
    
    var health: Int {get set}   //In the class that implements this protocol (conforming class, or conforming type), this variable can be accessed and mutated
    
    var pawn_name: String {get}    //In a conforming class, the variable must be defined as read only, e.g. let pawn_name = "Alex"
    
    func walk(speed: CGFloat)
    
    func walk(des: CGPoint, speed: CGFloat)
    
   func destroy_pawn()
    
    
    
}
