//
//  ViewController.swift
//  animation
//
//  Created by Alireza Moghaddam on 2019-05-09.
//  Copyright © 2019 Alireza. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var enemies = [enemy]()
    var totEnemies = 0

    override func viewDidLoad() {
        super.viewDidLoad()
       
       //Adding different types of gesture recognizers to the screen (self.view)
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "sky.png")!)
    
        let tap = UITapGestureRecognizer(target: self, action: #selector(taped))
        self.view.addGestureRecognizer(tap)
        
        let swipe = UISwipeGestureRecognizer(target: self, action: #selector(swiped))
        self.view.addGestureRecognizer(swipe)
        
        let pinch = UIPinchGestureRecognizer(target: self, action: #selector(pinched))
        self.view.addGestureRecognizer(pinch)
        
        //Emulating Pan gesture on the simulator could be pretty difficult and sometimes mixed up with swipe. So, I comment it out here.
        let pan = UIPanGestureRecognizer(target: self, action: #selector(panned))
        self.view.addGestureRecognizer(pan)
     
        let bounds = UIScreen.main.bounds
        let width = bounds.size.width
        let height = bounds.size.height
        
        //Throw 10 enemies randomly on the screen
       /*for _ in 0...9 {

            let x = arc4random_uniform(UInt32(width))
            let y = arc4random_uniform(UInt32(height))

            let tmp = enemy(someImg: UIImage(named: "frame-1.png")!, xPos: Int(x), yPos: Int(y), w: 50, h: 70)

            enemies.append(tmp)
        
            self.view.addSubview(tmp)
        }*/

        
    }
    
    // Event hadler functions for different types of gestures
    
    
    // All enemies will move toward the taped point on the screen
    @objc func taped(touch: UITapGestureRecognizer)
    {
        print("Tapped")
        
        
        let touchPoint = touch.location(in: self.view)
        
        let x = touchPoint.x
        let y = touchPoint.y
        
        let tmp = enemy(someImg: UIImage(named: "frame-1.png")!, xPos: Int(x), yPos: Int(y), w: 50, h: 70)
        
        enemies.append(tmp)
        
        self.view.addSubview(tmp)
        
        tmp.walkInPlace()
        
        totEnemies = totEnemies + 1
        print("totEnemies: \(totEnemies)")
        
        /*for i in 0...9 {
            
             let spd = arc4random_uniform(100) + 100
            enemies[i].walk(des: CGPoint(x: touchPoint.x, y: touchPoint.y), speed: CGFloat(spd))
            
        }*/
    }
    
    // All enemies will scatter on screen in random locations
    @objc func swiped()
    {
        print("Swiped")
        let bounds = UIScreen.main.bounds
        let width = bounds.size.width
        let height = bounds.size.height
        for i in 0...9 {
            let x = arc4random_uniform(UInt32(width))
            let y = arc4random_uniform(UInt32(height))
            let spd = arc4random_uniform(100) + 100
            enemies[i].walk(des: CGPoint(x: CGFloat(x), y: CGFloat(y)), speed: CGFloat(spd))
        }
    }
    
    // I have nothing to do when screen is pinched. Just a print command on the console would be enough to make sure that it works!!
    @objc func pinched()
    {
        print("Pinched")
    }
    @objc func panned(recognizer:UIPanGestureRecognizer)
    {
        print("Panned")
        
        //let vel = recognizer.translation(in: self.view)
        let vel = recognizer.velocity(in: self.view)
        print("vel.x = \(vel.x) | vel.y = \(vel.y)")
        //--Error without -1, empty index if totEnemies without -1
        for i in 0...totEnemies-1 {
            print("i = \(i)")
            let x = vel.x
            let y = vel.y
            enemies[i].walk(des: CGPoint(x: CGFloat(x), y: CGFloat(y)), speed: CGFloat(10.0))
        }
    }

}

