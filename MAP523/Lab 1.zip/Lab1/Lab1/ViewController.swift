//
//  ViewController.swift
//  Lab1
//
//  Created by Shan Ariel Sioson on 2019-05-08.
//  Copyright © 2019 dev. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var Lab1Label: UILabel!
    
    @IBOutlet weak var Lab1Field: UITextField!
    @IBOutlet weak var Lab1Button: UIButton!
    var global_var = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        Lab1Label.text = "Lab 1 Timer"
        Lab1Field.text = "Enter Time"
    }
    @IBAction func Pressed(_ sender: UIButton) {
        let result = Int(Lab1Field.text!)
        
        if(result! < 1 || result! > 60) {
            Lab1Label.text = "Entered number must not be less than 1 or greater than 60"
        }else {
            global_var = result!
            global_var = global_var * 60
            
            runTimer()
        }
    }

    @objc func updateTimer() {
        global_var = global_var - 1
        var min = global_var/60%60
        var sec = global_var%60
        Lab1Label.text = String(min) + ":" + String(sec)
    }
    @objc func runTimer()
    {
        let timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(ViewController.updateTimer), userInfo: nil, repeats: true)
    }
    

}

