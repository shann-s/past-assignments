//
//  ViewController.swift
//  animation
//
//  Created by Alireza Moghaddam on 2019-05-09.
//  Copyright © 2019 Alireza. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

   
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view
        
         self.view.backgroundColor = UIColor(patternImage: UIImage(named: "sky.png")!)
        
        var enemies = [enemy]()
        var bullets = [enemy.bullet]()
        
        let bounds = UIScreen.main.bounds
        let width = bounds.size.width
        let height = bounds.size.height
        
        for _ in 1...20 {
            
            let x = arc4random_uniform(UInt32(width))
            let y = arc4random_uniform(UInt32(height))
            let spd = arc4random_uniform(20) + 10
            
            let Dirx = arc4random_uniform(UInt32(width))
            let Diry = arc4random_uniform(UInt32(height))
           
            let tmp = enemy(someImg: UIImage(named: "frame-1.png")!, xPos: Int(x), yPos: Int(y), w: 50, h: 70)
            enemies.append(tmp)
            tmp.walk(speed: CGFloat(spd))
            self.view.addSubview(tmp)
            
            //bullets
            let tmp1 = enemy.bullet(sImg: UIImage(named:"bulletbill.png")!, xxPos: Int(x), yyPos: Int(y), ww: 50, hh: 70, xDir: Int(Dirx), yDir: Int(Diry))
            bullets.append(tmp1)
            tmp1.start()
            self.view.addSubview(tmp1)
            
        }
        
       

        
    }
    
  
  


}

