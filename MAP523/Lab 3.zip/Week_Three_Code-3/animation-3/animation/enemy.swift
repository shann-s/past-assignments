//
//  enemy.swift
//  animation
//
//  Created by Alireza Moghaddam on 2019-05-16.
//  Copyright © 2019 Alireza. All rights reserved.
//

import Foundation
import UIKit

public class enemy :  UIImageView  {    //The enemy class extends the UIImageView.
                                        //So, this class is an UIImageView and can be added to ViewController
    
    struct direction {
        
        var u: Int
        var v: Int
    }
    
    var iterator = 1
    var motionDirection = 1  //+1 indicates forward and -1 indicates backward
    var health = 100
    var timer: Timer?
    
    //init is the constructor of a class
    init(someImg: UIImage, xPos: Int, yPos: Int, w: Int, h: Int)
    {
        super.init(image: someImg)  //Calling the constructor of the parent
        self.frame = CGRect(x: xPos, y: yPos, width: w, height: h )
    }
    
    //Just to show that we can have multiple constructors in class
    init(someImg: UIImage)
    {
        super.init(image: someImg)
        self.frame = CGRect(x: 100, y: 100, width: 50, height: 70 )
    }
    
    //This function is used for serialization. This function is used for serialization and we do not explain it here.
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //Sets my position. Note: I am UIImageView
    func setPosition(xPos: CGFloat, yPos: CGFloat){
        
        self.frame.origin = CGPoint(x: xPos, y: yPos)
    
    }
    
    
    func walk(speed: CGFloat)
    {
        let spd = Double(1/speed)
        
        timer = Timer.scheduledTimer(timeInterval: spd, target: self, selector: #selector(animate), userInfo: nil, repeats: true)
    }
    
    @objc func animate(){
        
        //Kill myself whenever I get transparent and invisible
        if (self.alpha < 0) {
            
            self.timer!.invalidate()
            self.removeFromSuperview()
            //print("Killed")
        }
        
        self.image = UIImage(named: "frame-\(iterator).png")
        iterator += 1
        
        if (iterator == 5){
            iterator = 1
        }
        let stepSize = 10
         self.setPosition(xPos: self.frame.origin.x + CGFloat(motionDirection * stepSize), yPos: self.frame.origin.y)
        
        let bounds = UIScreen.main.bounds
        let width = bounds.size.width
        
        //When colliding with walls, the health gets decremented by 20
        //and transparency is reduced by 20%
        if (self.frame.origin.x > width - self.frame.width)
        {
            motionDirection = -1
            self.health -= 20
            self.alpha -= 0.2
        }
        else if(self.frame.origin.x < 0)
        {
            motionDirection = 1
            self.health -= 20
            self.alpha -= 0.2
        }
        
    }
    
    public class bullet: enemy {
        
        struct bulletdirection {
            
            var x: Int
            var y: Int
        }
        
        struct spawnpoint {
            var xPos: Int
            var yPos: Int
        }
        var speed: CGFloat = 0.0
        var spawn : spawnpoint = spawnpoint(xPos: 0, yPos: 0)
        var dir : bulletdirection = bulletdirection(x: 0, y: 0)
        var xDir = 1
        var yDir = 1

        
        init(sImg: UIImage, xxPos: Int, yyPos: Int, ww: Int, hh: Int, xDir: Int, yDir: Int) {
            
            //super.init()
            super.init(someImg: sImg, xPos: xxPos, yPos: yyPos, w: ww, h: hh)
            self.frame = CGRect(x: xxPos, y: yyPos, width: ww, height: hh )
            let spawn = spawnpoint(xPos: xxPos, yPos: yyPos)
            let dir = bulletdirection(x: xDir, y: yDir)
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
        
        func start() {
        
            speed = CGFloat(arc4random_uniform(20) + 10)
            let spd = Double(1/speed)
            timer = Timer.scheduledTimer(timeInterval: spd, target: self, selector: #selector(bulletShoot), userInfo: nil, repeats: true)
            

        }
        
        @objc func bulletShoot() {
        
            let bounds = UIScreen.main.bounds
            let width = bounds.size.width
            let height = bounds.size.height
            
            if ( self.frame.origin.x > width && self.frame.origin.y > height) {
                
                self.timer!.invalidate()
                self.removeFromSuperview()
                //print("Killed")
            }
            let stepSize = 10
            self.image = UIImage(named: "bulletbill.png")
            
            if (dir.x > 1 ) {
                xDir = 1
            } else {
                xDir = -1
            }
            
            if (dir.y > 1 ) {
                yDir = 1
            } else {
                yDir = -1
            }
            
            self.setPosition(xPos: self.frame.origin.x + CGFloat(xDir * stepSize), yPos: self.frame.origin.y + CGFloat(yDir * stepSize))
            
            
        }
    }
    
}

