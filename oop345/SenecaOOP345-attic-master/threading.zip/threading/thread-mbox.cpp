// http://stackoverflow.com/questions/16872593/c-c-implementation-of-a-mailbox-for-inter-thread-communication

// GB convert int try_XXX functions to bool
// GB convert messageT *msg to messageT&

#include <iostream>
#include <string> // GB expand template with a string
#include <chrono>

#include <thread>
#include <condition_variable>
#include <queue>

using namespace std;

template <class messageT>
class Mailbox {

    private:
        std::condition_variable  msg_available_cv;  // Message in the mailbox?
        std::mutex               queue_mutex;       // Mutex for queue control

        queue<messageT>          messages;          // Messages

    public:
        Mailbox(void)  { }
        ~Mailbox(void) { }

        void put(messageT msg) { // Put a single message into the mailbox

            std::unique_lock<std::mutex> lock(queue_mutex);

            // Push message into mailbox
            messages.push(msg);

            // Signal there is a message in the mailbox
            msg_available_cv.notify_one();
        }

        bool try_put(messageT msg) { // Try to put a single message into the mailbox

            if( queue_mutex.try_lock() ) {

                // Push message into mailbox
                messages.push(msg);

                // Signal there is a message in the mailbox
                msg_available_cv.notify_one();

                // Unlock queue
                queue_mutex.unlock();

                return true;
            }
            // Otherwise, say mailbox is unavailable
            else
                return false;
        }

        void get(messageT& msg) { //  Get single message from a mailbox

            std::unique_lock<std::mutex> lock(queue_mutex);

            // Wait for a message to come in
            while(messages.empty()) {
                msg_available_cv.wait(lock);
            }

            // Pop of least recent message
            msg = messages.front();
            messages.pop();
        }

        bool try_get(messageT& msg) { //  Try to get single message from a mailbox

            int mailbox_ready = true;  // Mailbox ready

            std::unique_lock<std::mutex> lock(queue_mutex);

            // Indicate if mailbox is empty
            if(messages.empty())
                mailbox_ready = false;
            // Otherwise, grab the message
            else {
                // Pop of least recent message
                msg = messages.front();
                messages.pop();
            }

            return mailbox_ready;
        }

        void peek(messageT& msg) { //  Peek at single message from a mailbox

            std::unique_lock<std::mutex> lock(queue_mutex);

            // Wait for a message to come in
            while(messages.empty()) {
                msg_available_cv.wait(queue_mutex);
            }

            // Peek at most recent message
            msg = messages.front();
        }

        bool try_peek(messageT& msg) { //  Try to peek at single message from a mailbox

            bool mailbox_ready = true;  // Mailbox ready

            std::unique_lock<std::mutex> lock(queue_mutex);

            if(messages.empty())    // Indicate if mailbox is empty
                mailbox_ready = false;
            else                    // Otherwise, grab the message
                msg = messages.front();

            return mailbox_ready;
        }

        bool empty() { //  message available? 

            std::unique_lock<std::mutex> lock(queue_mutex);

            return messages.size() == 0;
        }

        int count() { //  message count

            std::unique_lock<std::mutex> lock(queue_mutex);

            return messages.size();
        }
};

int main(int argc, char**argv)
{
  std::mutex      cout_mutex;       // Mutex for 'cout'
  Mailbox<string> mb;

  auto get     = [&mb,&cout_mutex] () -> void { 
       string Msg; 
       bool waited = false;

       std::chrono::time_point<std::chrono::high_resolution_clock> start;
       start = std::chrono::high_resolution_clock::now();

       if(mb.empty()) {
         std::unique_lock<std::mutex> lock(cout_mutex);
         std::cout<< "get: mailbox empty - waiting for message: " << this_thread::get_id() << "\n"; 
         waited = true;
       }
       mb.get(Msg); 
       std::unique_lock<std::mutex> lock(cout_mutex);

       std::chrono::time_point<std::chrono::high_resolution_clock> stop;
       stop  = std::chrono::high_resolution_clock::now();
       typedef std::chrono::duration<int,std::milli> millisecs_t ;
       millisecs_t duration_get( std::chrono::duration_cast<millisecs_t>(stop-start) ) ;
       long tWait = duration_get.count();

       std::cout<< "get: " << tWait << " msec wait time " << (waited? "message arrived ": "")  << this_thread::get_id() << " " << Msg << "\n"; 
  };

  auto try_get = [&mb,&cout_mutex] () -> void { 
       string Msg; 
       std::unique_lock<std::mutex> lock(cout_mutex);
       std::cout<< "try_get: " << this_thread::get_id() << " " << (mb.try_get(Msg)? Msg: "mail box empty") << "\n"; 
  };

  mb.put(string("msg 1"));  // Put a single message into the mailbox

  string Msg;
  // mb.get(Msg); std::cout << Msg << "\n";
  try_get();

  mb.put(string("msg 2"));  // Put a single message into the mailbox
  mb.put(string("msg 3"));  // Put a single message into the mailbox
  mb.put(string("msg 4"));  // Put a single message into the mailbox
  mb.put(string("msg 5"));  // Put a single message into the mailbox
        // void put(messageT msg); // Put a single message into the mailbox
        // bool try_put(messageT msg); // Try to put a single message into the mailbox
        // void get(messageT& msg); //  Get single message from a mailbox
        // bool try_get(messageT& msg); //  Try to get single message from a mailbox
        // void peek(messageT& msg); //  Peek at single message from a mailbox
        // bool try_peek(messageT& msg); //  Try to peek at single message from a mailbox


  std::thread t1 (get);
  std::thread t2 (try_get);
  std::thread t3 (try_get);
  t1.join();
  t2.join();
  t3.join();
  try_get();
  try_get();
  try_get();
  try_get();

  std::thread t4 (get);
  this_thread::sleep_for (std::chrono::milliseconds(750));
  mb.put(string("msg 6"));  // Put a single message into the mailbox
  t4.join();
}
