import java.util.Calendar;

/**
* The Book class implements ...
*
* @author  ....
*/
class Book {

    String       bookName;    // the book name
    int          valueTag;    // an integer between -100 and 100
    Library      library;     // the library having this book it its inventory
    RentSettings rs;          // rent settings

    public Book(String bookName, int valueTag){					//Book construct sets name, value tag, and rent settings
       this.bookName = bookName;
       this.valueTag = valueTag;
       RentSettings rs = new RentSettings();
       setRs(rs);
    }
    
    public void setlibrary(Library library){					//Sets book library to passing library
    	this.library = library;
    }
    
    public String displayRs() {									//Displays rensettings
    	return rs.display(library);
    }

    public String getbooks() {
    	String s = "(" + bookName + ", " +valueTag+ " => " + library.getLibraryName() + ") RentSettings(" +displayRs()+ ")" ;
    	return s;												//Displays book information
    }

    // set the rent dates; if dates are not valid catch DateFormatException and return false,
    // if rentDate > dueDate catch RentPeriodException and return false
    // if one the exceptions occur there is no RentSettings object
    public boolean rentBook(String rentDate, String dueDate, Library library) {

        try {
        	if(isBookOverdue()) {													//if book is overdue deny rent
        		return false;
        	}
			RentSettings rs = new RentSettings(rentDate, dueDate, library);			//sets rent settings
			this.rs = rs;																	
			this.library = null;													//set library to null for rent
			return true;															//return true for book successfully rent
		} catch (DateFormatException e) {
			e.printStackTrace();
			return false;
		} catch (RentPeriodException e) {
			e.printStackTrace();
			return false;
		}
    }

    // destroy the RentSettings object for this book and add back the library
    public void returnBook(Library library) {
        RentSettings rs = new RentSettings();
        setRs(rs);
        this.library = library;
    }

    // return the date when this book is available
    public String availableDate(Library library) {
    	String s;
    	if(isBookOverdue())														//Gets the available date unless it is overdue or already rent
    		return s = "Book is overdue";
    		
    	if( isRented(library) ){												//If already rent send out due date for avalability
    		return s = "Expected book avilability date: " + rs.getdueDate();
    	}else {
    		return s = "Book is available now!";								
    	}
    }

    // returns true (1) if the current date is greater than the due date
    public boolean isBookOverdue(){
       String cur = Helper.getCurrentDate();
       String due = rs.getdueDate();
       
       int comp = cur.compareTo(due);
       if (comp == 1) {
    	   return true;
       }else
    	   return false;
    }

    public boolean isRented(Library l) {
    	if(library == null){													//If library is null it is rented
    		return true;
    	}else{
    		return false;
    	}
    }

    public RentSettings getRs() {												//returns rent settings
       RentSettings rs = null;
       rs = this.rs;
       return rs;
    }

    public void setRs(RentSettings rs) {										//sets rent settings
    	this.rs = rs;
    }

    @Override
    public boolean equals(Object o) {
       if(o == this) {
    	   return true;
       }else{
    	   return false;
       }
    }

    @Override
    public int hashCode() {
      return 1;
    }

    @Override
    public String toString() {
    	String s = "";
    	return s;
    }

    public String bookName() {
        return "(" + bookName + ", " + valueTag + ')';
    }
    
    public Boolean bookMatch(String book, int val) {
    	if((book).equals(bookName) && val == valueTag) {					//If book name and value tag is the same return true
    		return true;													//else return false
    	}else {
    		return false;
    	}
    }
    
    public String getName() {												//returns book name
    	return bookName;
    }
    
    public int getVal() {													//return value tag
    	return valueTag;
    }
    

    private class RentSettings {

        private String rentDate;          // date when the item is requested
        private String dueDate;           // date when the item must be returned
        private boolean borrowed; // true if the item is rented

        //default ctr
        private RentSettings() {
           rentDate = "0/0/0";											//constructor sets rent settings as in library and not borrowed
           dueDate = "0/0/0";
           borrowed = false;
           
        }
        
        private String getdueDate(){									//retrieves due date
        	return dueDate;	
        }	
        
        private String display(Library library) {						//Displays rent settings
        	return rentDate + ", "+dueDate+ ", " + library.getLibraryName() + ", " + borrowed;				
        }

        // private ctr must throw DateFormatException and RentPeriodException
        private RentSettings(String rentDate, String dueDate, Library library)
                throws DateFormatException, RentPeriodException {
        	this.rentDate = rentDate;									//Sets passing args rent settings to this rentsettings
        	this.dueDate = dueDate;
        	borrowed = true;											//sets rent settings as borrowed
        }
        
        private boolean getborrow(){									//returns the borrowed
        	return borrowed;
        }

        @Override
        public String toString() {
            return "";
        }
    }
}
