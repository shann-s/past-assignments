//Student ID: 026649152
public class Main {

    public static void main(String[] args) {


    	System.out.println("\n\n *" + " TASK 1 " + "*");
        Libraries ls = new Libraries(/* your number of libraries */2);
       
        Library Newnham = ls.buildLibraryFromFile("Newnham", "NewnhamLibrary.txt");			//Sets libraries in their respective library
        System.out.println("\n");
        Library York = ls.buildLibraryFromFile("York", "YorkLibrary.txt");

        /* TASK 2 - ask for a book that is not in any library inventory */

        System.out.println("\n\n *" + " TASK 2 " + "*");
        Book book = new Book("C++", 20);
        
        Library library = ls.isThereBookInLibraries(book);		//Looks for books in all libraries
        if (library == null)
            System.out.println(book.bookName() + " " +Helper.printNonexistent(book));

        if (library != null)
        	System.out.println("Book Exists!");											//Debugging purposes
        
         /* TASK 3 - ask for a book that is in a library inventory
         *  issue a rent request and print the book Essentials of Database Management
         *  issue the same rent request and print the book
         *  return the book
         *  issue the rent request with new dates and print the book
         */
        
        System.out.println("\n\n *" + " TASK 3 " + "*");
        
        book = new Book("Essentials of Database Management", 25);
        
        System.out.println("Asking for book " + book.bookName() + " \n");
        
        library = ls.isThereBookInLibraries(book);											//Looks for books in all libraries
        
        if (library == null)
            System.out.println(Helper.printNonexistent(book));

        String CurDate = Helper.getCurrentDate();
        if (library != null){
        	System.out.println(book.bookName() + " Book Exists!\n");
        	library = ls.rentBookAvailable(book, CurDate, "03/31/2017");					//Rent Book
        	library = ls.rentBookAvailable(book, CurDate, "03/31/2017");					//Rent book that is already rented
        	ls.returnBook(book);															//Return Book
        	//library = ls.rentBookAvailable(book, h.getCurrentDate(), "03/31/2017");		//Debugging purposes
        }
        
        library = ls.isThereBookInLibraries(book);
        if (library == null)
            System.out.println(Helper.printNonexistent(book));

        if (library != null){
        	library = ls.rentBookAvailable(book, CurDate, "04/14/2018");			//Rent Book with new dates
        }
         /* TASK 4 - ask for the same book in all libraries
          * if you can find a library, rent the book from that library
          * 
          * TASK 4 - ask for the same book in all libraries
				- look for the same book in all libraries and return a library, if the book is in the library inventory(*)
				- look for the same book in all libraries and return a library, if the book is available to be borrowed from that library*. 
				(* the library returned is the first library found from the array of libraries)
          */
        Book temp = null;
        
        System.out.println("\n\n *" + " TASK 4 " + "*");
        
        library = ls.isThereBookInLibraries(book);										//Looks for books in all libraries returns library with book
        temp = library.findbook(book);													//returns book from found library
        
        System.out.println("Asking for book " + temp.bookName() + " \n");				
    
        System.out.println(library.getLibraryName() + " Library returned");				
        
        System.out.println("York Library \n" + library.Bookavailable(temp, library) + "\n");	//returned library if the book is available to be borrowed
        
        /* TASK 5 - calculate maximum value tag for each library */
        System.out.println("\n\n *" + " TASK 5 " + "*");
        
        System.out.println("York Library max value tag: " + York.findMaximumValueTag() + "\n");		//Finds max value tag in york
        System.out.println("Newnham Library max value tag: " + Newnham.findMaximumValueTag() );		//Finds max value tag in newnham
        
        
         /* TASK 6 - inquire about a book - it is available? when does it become available, etc. */
        System.out.println("\n\n *" + " TASK 6 " + "*");
        book = new Book("Introductory Statistics with R",-95);										//New book
        
        library = ls.isThereBookInLibraries(book);													//Looks for book in libraries
        
        temp = library.findbook(book);																//Finds book in found library
        
        System.out.println("Asking for book " + temp.bookName() + " \n");							//Print book name
        
        System.out.println("York Library \n" + York.Bookavailable(temp, York) + "\n");				//Looks for book in york and newnham
        System.out.println("Newnham Library \n" + Newnham.Bookavailable(temp, Newnham) + "\n");
    }
}
