/** Documentation 
    @author: 
*/
public class DateFormatException extends Exception {
    public DateFormatException() {}
    public DateFormatException(String message) {
        super(message);
    }
}
