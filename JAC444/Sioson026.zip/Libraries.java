import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Libraries {

    public Library[] libraries;        // a collection of libraries of type array
    public int numberOfLibraries;      // number of libraries in collection
    public int libCount;			   // Current library counter

    public Libraries(int c) {
    	numberOfLibraries = c;
    	libCount = 0;
    	libraries = new Library[c];
    }
    
    public Library getLib(int i){
    	return libraries[i];
    }
    
    public Library buildLibraryFromFile(String libraryName, String fileName) {

        Library library = new Library(libraryName);		//Library file name
        String path = System.getProperty("user.dir");
        Book book = null;
        String s;
        libraries[libCount] = library;					//Library 0 - Newnham
        												//Library 1 - York
         try (BufferedReader br = new BufferedReader(new FileReader(path + "/src/" + fileName))) {
        // if you run locally on your environment use: new FileReader(path + "/src/" + fileName)

            while ((s = br.readLine()) != null) {
            	String[] info = s.split(",");								//Split libraries
            	book = new Book(info[0], Integer.parseInt(info[1]));		//Add the string from 
            	book.setlibrary(library);									//Set the book's library 
            	libraries[libCount].setbooks(book, libraryName);			//Set each libraries a book and its library name
            	System.out.println(book.getbooks());							//Print book properties
            }
            
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
         libCount++;														//For the next library (York) add to the libcount for the collection
        return library;														//Returns the library created
    }

    public Library isThereBookInLibraries(Book book) {
    	Book t;
    	Library j = null;
    	for (int i = 0; i < libraries.length; i++) {		//Loops through library for book
    		j = libraries[i];
    		t = j.findbook(book);							//Finds the matching book in library from array
    		if(t != null) {									//If results are true library...
    			return j;									//Return the current library
    		}
    	}
       return null;											//If no matching found in library return null
    }


    public Library rentBookAvailable(Book book, String requestDate, String dueDate) {

        Library foundLibrary = null;
        
        foundLibrary = isThereBookInLibraries(book);
        
        if(foundLibrary != null) {
        	
        	if(foundLibrary.rentRequest(book, requestDate, dueDate, foundLibrary) == true) {
        		return foundLibrary;
        	}else {
        		foundLibrary = null;
        		return foundLibrary;
        	}
        	
        }else{
        	return foundLibrary;
        }
    }
    
    public void returnBook(Book Books){
    	
        Library foundLibrary = null;
        
        foundLibrary = isThereBookInLibraries(Books);
        
        if(foundLibrary != null) {
        	
        	foundLibrary.returnBook(Books, foundLibrary);
        	System.out.println(Books.bookName() + " Book returned!\n");
        }else{
        	System.out.println("Book has not been returned\n");
        }
    }
    
}
