import java.util.Iterator;
import java.util.Vector;

public class Library implements MaxTagValue {


    String       libraryName;
    Vector<Book> books = new Vector();
    
    public Library(String libraryName) {
        this.libraryName = libraryName;							//Construct for new library setting library name
    }
    
    public void setbooks(Book newBook, String libraryName){		//Add new book with the library name
    	setLibraryName(libraryName);
    	books.addElement(newBook);
    }
    
    public void setLibraryName(String name){					//Set library name
    	libraryName = name;
    }
    
    public void removelib() {									//Remove library
    	libraryName = "";
    }
    
    public String getLibraryName(){								//Gets library name
    	return libraryName;
    }
    
    public Book books(int i){									//Returns book at index i
    	return books.get(i);
    }
    
    public Book findbook(Book match) {
    	Book s = null;
    	Boolean x = false;
    	for(int i = 0; i < books.size(); i++){					//Loops from the vector<books> book collections
    		s = books.get(i);									//Gets the element ID from books and puts in temporary Book class
    		x = s.bookMatch(match.getName(), match.getVal());	//Looks for match in book class
    		if(x == true) {										//If match found return true
    			return s;
    		}
    	}
    	
    	return null;											//If no match found return false

    }

    public int findMaximumValueTag() {

        int maxElement = -100;									//Max element set at lowest possible

        Book temp = null;										//Create temporary empty book
        
        for (int i = 0; i < books.size(); i++) {	
        	temp = books.get(i);								//Gets book from the collection of books
        	if(temp.getVal() > maxElement) {					//if the value of the book is greater than max element
        		maxElement = temp.getVal();						//store tag value in max element
        	}
        }
        
        return maxElement;										//returns max element
    }
    
    public boolean rentRequest(Book wanted, String requestDate, String dueDate, Library lib) {

        try {
            Helper.checkDate(requestDate);
            Helper.checkDate(dueDate);
            
            Book found = null;													//Creates empty book
            found = findbook(wanted);											//Finds book wanted
            if(found.isRented(lib) != true) {									//The found book is checked if its rented
                found.rentBook(requestDate, dueDate, lib);						//if it is not rented (not true) the book is issued a
                String s = found.bookName();									//rent in the appropriate book
                System.out.println("Rented book: "+ s + " in " + getLibraryName() + ".\nRequest Date: " + requestDate + " Due Date: " + dueDate + "\n");
                return true;													//returns true that the book is rented
            	
            }else {																//If the book is rented (true) state a rent out and 
            	System.out.println(wanted.getName() + " is already rent out...\n");
            	return false;													//return false
            }
        } catch (DateFormatException e) {
            System.out.println(wanted + e.getMessage());
            return true;
        }
    }
    
    public void returnBook(Book returnedbook, Library lib) {
    	
    	
        Book found = null;
        found = findbook(returnedbook);											//find the returned book
        
        if(found == null) {														//If no book found state does not exists
        	System.out.println("Returned book does not exist!");
        }
        else
        found.returnBook(lib);													//Else return the book
    }
    
    public String Bookavailable(Book wanted, Library expected) {				//Asks if book is available
    	
    	String s;
    	Book found = null;
    	found = findbook(wanted);												//Finds book wanted
    	
    	if(found == null)														//If book is not found in library say it is not available
    		return s = "Book Is Not Available Here";
    	else																	//Else return the available date in book
    		return s = found.availableDate(expected);
    }
}
