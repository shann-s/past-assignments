public interface MaxTagValue {

    /**
     * The method returns an integer. 
     * The integer is the greatest value of all tagValues 
     */
    int findMaximumValueTag();
    
    
}
